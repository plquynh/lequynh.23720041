# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 19:51:36 2024

@author: Phan Le Quynh 23720041 
"""
nam_sinh = int(input("Nhap vao nam sinh:"))
nam_hien_tai = 2023
tuoi = nam_hien_tai - nam_sinh
print("Ban sinh nam:",(nam_sinh),("vay ban:"),tuoi,("tuoi"))
